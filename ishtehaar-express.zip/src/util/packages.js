export const packages = [
  {
    title: "Basic Zone",
    price: "Rs 250,000",
    features: [
      "5 Screens",
      "5 Hours Daily Display Time",
      "1 City Zone Coverage",
    ],
  },
  {
    title: "Premium Zone",
    price: "Rs 399,999",
    features: [
      "10 Screens",
      "8 Hours Daily Display Time",
      "2 City Zones Coverage",
    ],
  },
  {
    title: "Citywide Elite",
    price: "Rs 799,999",
    features: [
      "12 Screens",
      "12 Hours Daily Display Time",
      "3 City Zones Coverage",
    ],
  },
];
