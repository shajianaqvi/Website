export const carouselItems = [
  {
    img: "/images/car.jpg",
    title: "Premium Brand Campaign",
    desc: "Increased visibility by 40% in downtown areas",
  },
  {
    img: "/images/car.jpg",
    title: "Tech Launch Campaign",
    desc: "Created city-wide awareness for product launch",
  },
  {
    img: "/images/car.jpg",
    title: "Restaurant Chain Promotion",
    desc: "Boosted new location traffic by 65%",
  },
  {
    img: "/images/car.jpg",
    title: "Fashion Season Rollout",
    desc: "Targeted high-end shopping districts",
  },
];
