import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/Header";
import Content from "./components/Content";
import Footer from "./components/Footer";
import AuthMenu from "./components/AuthMenu";
import BlogDetails from "./components/BlogDetails";

const App = () => {
  const [isLoginActive, setIsLoginActive] = useState(false);
  const [isSignupActive, setIsSignupActive] = useState(false);

  const openLogin = () => {
    setIsLoginActive(true);
    setIsSignupActive(false);
  };

  const openSignup = () => {
    setIsSignupActive(true);
    setIsLoginActive(false);
  };

  const closeMenus = () => {
    setIsLoginActive(false);
    setIsSignupActive(false);
  };

  return (
    <Router>
      <Header openLogin={openLogin} openSignup={openSignup} />
      <AuthMenu
        isLoginActive={isLoginActive}
        isSignupActive={isSignupActive}
        closeMenus={closeMenus}
      />
      <Routes>
        <Route path="/" element={<Content />} />
        <Route path="/blog/:id" element={<BlogDetails />} />
      </Routes>
      <Footer />
    </Router>
  );
};

export default App;
