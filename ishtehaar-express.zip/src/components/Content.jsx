import React from "react";
import Carousel from "./Carousel";
import Blog from "./Blog";
import Contact from "./Contact";
import About from "./About";
import Packages from "./Packages";

const Content = () => {
  return (
    <main>
      {/* Hero Section */}
      <section id="hero">
        <div className="container">
          <div className="hero-content">
            <h1>Advertise Your Brand on Wheels</h1>
            <p>
              Reach thousands of potential customers daily with strategic mobile
              advertisements displayed on taxi LCD screens across high-traffic
              zones.
            </p>
            <div className="hero-buttons">
              <a href="#packages" className="btn btn-primary scroll-link">
                View Packages
              </a>
              <a href="#contact" className="btn btn-secondary scroll-link">
                Contact Us
              </a>
            </div>
          </div>
        </div>
      </section>

      <Carousel />
      <About />
      <Packages />
      <Blog />
      <Contact />
    </main>
  );
};

export default Content;
