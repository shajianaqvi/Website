import React, { useState } from "react";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const [formStatus, setFormStatus] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Simulate form submission
    setFormStatus("Thank you for your message! We will get back to you soon.");
    setFormData({
      name: "",
      email: "",
      subject: "",
      message: "",
    });

    // Clear the status message after 5 seconds
    setTimeout(() => setFormStatus(""), 5000);
  };

  return (
    <section id="contact" className="section">
      <div className="container">
        <h2 className="section-title">Contact Us</h2>
        <p>
          Have questions or ready to get started? Reach out to our team for
          personalized assistance.
        </p>

        <div className="contact-container">
          {/* Contact Info */}
          <div className="contact-info">
            <div className="contact-info-item">
              <div className="contact-icon">📍</div>
              <div>
                <h3>Address</h3>
                <p>
                  Fast Nuces, AK Brohi Road
                  <br />
                  Islamabad, Pakistan 46000
                </p>
              </div>
            </div>

            <div className="contact-info-item">
              <div className="contact-icon">📱</div>
              <div>
                <h3>Phone</h3>
                <p>+0900 78601</p>
              </div>
            </div>

            <div className="contact-info-item">
              <div className="contact-icon">✉️</div>
              <div>
                <h3>Email</h3>
                <p>info@ishtehaarexpress.com</p>
              </div>
            </div>

            <div className="contact-info-item">
              <div className="contact-icon">⏰</div>
              <div>
                <h3>Business Hours</h3>
                <p>
                  Monday - Friday: 9:00 AM - 6:00 PM
                  <br />
                  Saturday: 10:00 AM - 2:00 PM
                </p>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="contact-form">
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <input
                  type="text"
                  name="name"
                  className="form-control"
                  placeholder="Your Name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <input
                  type="email"
                  name="email"
                  className="form-control"
                  placeholder="Your Email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <input
                  type="text"
                  name="subject"
                  className="form-control"
                  placeholder="Subject"
                  value={formData.subject}
                  onChange={handleChange}
                />
              </div>
              <div className="form-group">
                <textarea
                  name="message"
                  className="form-control"
                  placeholder="Your Message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                ></textarea>
              </div>
              <button type="submit" className="btn btn-primary">
                Send Message
              </button>
            </form>
            {formStatus && <p className="form-status">{formStatus}</p>}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
