import React, { useState } from "react";

const AuthMenu = ({ isLoginActive, isSignupActive, closeMenus }) => {
  return (
    <>
      {/* Overlay */}
      {(isLoginActive || isSignupActive) && (
        <div className="overlay" onClick={closeMenus}></div>
      )}

      {/* Login Menu */}
      {isLoginActive && (
        <div className="auth-menu active">
          <button className="menu-close" onClick={closeMenus}>
            ✕
          </button>
          <h3>Login to Your Account</h3>
          <form
            className="auth-form"
            onSubmit={(e) => {
              e.preventDefault();
              alert("Login functionality not implemented yet.");
              closeMenus();
            }}
          >
            <div className="form-group">
              <input
                type="email"
                className="form-control"
                placeholder="Email Address"
                required
              />
            </div>
            <div className="form-group">
              <input
                type="password"
                className="form-control"
                placeholder="Password"
                required
              />
            </div>
            <button type="submit" className="btn btn-primary">
              Login
            </button>
            <p>
              Don't have an account?{" "}
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  closeMenus();
                }}
              >
                Sign Up
              </a>
            </p>
          </form>
        </div>
      )}

      {/* Signup Menu */}
      {isSignupActive && (
        <div className="auth-menu active">
          <button className="menu-close" onClick={closeMenus}>
            ✕
          </button>
          <h3>Create an Account</h3>
          <form
            className="auth-form"
            onSubmit={(e) => {
              e.preventDefault();
              alert("Signup functionality not implemented yet.");
              closeMenus();
            }}
          >
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                placeholder="Full Name"
                required
              />
            </div>
            <div className="form-group">
              <input
                type="email"
                className="form-control"
                placeholder="Email Address"
                required
              />
            </div>
            <div className="form-group">
              <input
                type="password"
                className="form-control"
                placeholder="Password"
                required
              />
            </div>
            <div className="form-group">
              <input
                type="password"
                className="form-control"
                placeholder="Confirm Password"
                required
              />
            </div>
            <button type="submit" className="btn btn-primary">
              Sign Up
            </button>
            <p>
              Already have an account?{" "}
              <a
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  closeMenus();
                }}
              >
                Login
              </a>
            </p>
          </form>
        </div>
      )}
    </>
  );
};

export default AuthMenu;
