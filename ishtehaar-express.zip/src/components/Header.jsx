import React, { useEffect } from "react";

const Header = ({ openLogin, openSignup }) => {
  useEffect(() => {
    const menuToggle = document.querySelector(".menu-toggle");
    const navLinks = document.querySelector(".nav-links");

    menuToggle.addEventListener("click", () => {
      menuToggle.classList.toggle("active");
      navLinks.classList.toggle("active");
    });

    const handleScroll = () => {
      const header = document.querySelector("header");
      if (window.scrollY > 50) {
        header.classList.add("scrolled");
      } else {
        header.classList.remove("scrolled");
      }
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      menuToggle.removeEventListener("click", () => {});
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  return (
    <header id="header">
      <div className="container header-container">
        <div className="logo">
          <h1>
            Ishtehaar <span>Express</span>
          </h1>
        </div>
        <div className="menu-toggle">
          <div className="bar"></div>
          <div className="bar"></div>
          <div className="bar"></div>
        </div>
        <div className="nav-links">
          <ul>
            <li>
              <a href="#about" className="scroll-link">
                About Us
              </a>
            </li>
            <li>
              <a href="#packages" className="scroll-link">
                Packages Details
              </a>
            </li>
            <li>
              <a href="#blog" className="scroll-link">
                Blog
              </a>
            </li>
            <li>
              <a href="#contact" className="scroll-link">
                Contact Us
              </a>
            </li>
          </ul>
          <div className="auth-buttons">
            <button className="btn btn-secondary btn-auth" onClick={openLogin}>
              Login
            </button>
            <button className="btn btn-primary btn-auth" onClick={openSignup}>
              Sign Up
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
