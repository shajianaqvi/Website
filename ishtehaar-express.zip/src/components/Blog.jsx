import React from "react";
import { Link } from "react-router-dom";
import { blogs } from "../util/blogsContent";

const Blog = () => {
  return (
    <section id="blog" className="section">
      <div className="container">
        <h2 className="section-title">Latest From Our Blog</h2>
        <p>
          Discover insights, tips, and success stories about outdoor advertising
          and brand promotion.
        </p>
        <div className="blog-container">
          {blogs.map((post) => (
            <div className="blog-card" key={post.id}>
              <div
                className="blog-image"
                style={{ backgroundImage: `url(${post.image})` }}
              ></div>
              <div className="blog-content">
                <div className="blog-date">{post.date}</div>
                <h3 className="blog-title">{post.title}</h3>
                <p className="blog-excerpt">{post.excerpt}</p>
                <Link to={`/blog/${post.id}`} className="read-more">
                  Read More
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Blog;
