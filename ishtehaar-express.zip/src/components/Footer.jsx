import React from "react";

const Footer = () => {
  return (
    <footer>
      <div className="container">
        <div className="footer-container">
          {/* About Section */}
          <div className="footer-about">
            <div className="footer-logo">
              Ishtehaar <span>Express</span>
            </div>
            <p>
              Revolutionizing outdoor advertising with strategic taxi-mounted
              digital displays that bring your brand to life across busy urban
              environments.
            </p>
            <div className="social-links">
              <a href="#" className="social-link">
                f
              </a>
              <a href="#" className="social-link">
                t
              </a>
              <a href="#" className="social-link">
                in
              </a>
              <a href="#" className="social-link">
                ig
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="footer-links-column">
            <h3 className="footer-title">Quick Links</h3>
            <ul className="footer-links">
              <li>
                <a href="#hero">Home</a>
              </li>
              <li>
                <a href="#about">About Us</a>
              </li>
              <li>
                <a href="#packages">Packages</a>
              </li>
              <li>
                <a href="#blog">Blog</a>
              </li>
              <li>
                <a href="#contact">Contact</a>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div className="footer-links-column">
            <h3 className="footer-title">Services</h3>
            <ul className="footer-links">
              <li>
                <a href="#">Taxi Advertising</a>
              </li>
              <li>
                <a href="#">Ad Design</a>
              </li>
              <li>
                <a href="#">Campaign Management</a>
              </li>
              <li>
                <a href="#">Analytics & Reporting</a>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div className="footer-links-column">
            <h3 className="footer-title">Support</h3>
            <ul className="footer-links">
              <li>
                <a href="#">FAQ</a>
              </li>
              <li>
                <a href="#">Privacy Policy</a>
              </li>
              <li>
                <a href="#">Terms & Conditions</a>
              </li>
              <li>
                <a href="#">Help Center</a>
              </li>
              <li>
                <a href="#">Careers</a>
              </li>
            </ul>
          </div>
        </div>

        <div className="copyright">
          <p>&copy; 2025 Ishtehaar Express. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
