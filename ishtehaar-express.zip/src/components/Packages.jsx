import React from "react";
import { packages } from "../util/packages";

const Packages = () => {
  return (
    <section id="packages" className="section">
      <div className="container">
        <h2 className="section-title">Advertising Packages</h2>
        <p>
          Choose the perfect package to showcase your brand across the city. Our
          strategic zones are designed to maximize visibility and reach your
          target audience effectively.
        </p>

        <div className="packages-container">
          {packages.map((pkg, index) => (
            <div className="package-card" key={index}>
              <div className="package-header">
                <h3>{pkg.title}</h3>
              </div>
              <div className="package-content">
                <div className="package-price">
                  {pkg.price}
                  <span>/month</span>
                </div>
                <ul className="package-features">
                  {pkg.features.map((feature, i) => (
                    <li key={i}>
                      <strong>{feature}</strong>
                    </li>
                  ))}
                </ul>
                <div className="package-button">
                  <a href="#" className="btn btn-primary">
                    Get Started
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Packages;
