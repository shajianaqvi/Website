import React from "react";

const About = () => {
  return (
    <section id="about" className="section">
      <div className="container">
        <h2 className="section-title">About Us</h2>
        <div className="about-content">
          <div className="about-text">
            <p>
              Ishtehaar Express is revolutionizing outdoor advertising by
              bringing brands to life on moving digital billboards. Our network
              of LCD screens mounted on taxis offers unprecedented reach and
              visibility in urban environments.
            </p>
            <p>
              Founded in 2023, we've quickly grown to become the premier taxi
              advertising platform with a presence in major metropolitan areas.
              Our innovative approach combines traditional outdoor advertising
              with digital technology to create dynamic, targeted campaigns that
              capture attention.
            </p>
            <p>
              Our mission is to provide affordable, effective advertising
              solutions that help businesses of all sizes increase their brand
              visibility and connect with their target audience. By
              strategically placing advertisements in high-traffic areas, we
              ensure maximum exposure and impact for your marketing message.
            </p>
          </div>
          <div className="about-image">
            <img
              src="images/images.jfif"
              alt="Taxi with LCD advertisement screen"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
