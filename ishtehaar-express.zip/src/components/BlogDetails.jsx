import React from "react";
import { useParams } from "react-router-dom";
import { blogs } from "../util/blogsContent";

const BlogDetails = () => {
  const { id } = useParams();
  const blog = blogs.find((post) => post.id === parseInt(id));

  if (!blog) {
    return <p>Blog not found.</p>;
  }

  // Split content into paragraphs based on double newlines
  const contentParagraphs = blog.content
    .split(/\n+/)
    .map((paragraph, index) => (
      <p key={index} style={{ marginBottom: "1rem" }}>
        {paragraph.trim()}
      </p>
    ));

  return (
    <div
      style={{
        backgroundColor: "white",
        color: "#333",
        lineHeight: 1.6,
        margin: 0,
        padding: 0,
      }}
    >
      <div
        style={{
          backgroundColor: "#FF6B35",
          color: "white",
          padding: "20px 0",
          textAlign: "center",
          position: "absolute",
          width: "100%",
          top: "4rem",
        }}
      >
        <h1 style={{ margin: 0, fontSize: "2.5rem" }}>{blog.title}</h1>
      </div>
      <main
        style={{
          maxWidth: "800px",
          margin: "20px auto",
          padding: "20px",
          background: "white",
          borderRadius: "8px",
          boxShadow: "0 5px 15px rgba(0, 0, 0, 0.1)",
          marginTop: "200px",
        }}
      >
        <div
          style={{
            width: "100%",
            height: "auto",
            borderRadius: "8px",
            marginBottom: "20px",
            backgroundImage: `url(${blog.image})`,
            backgroundSize: "cover",
            backgroundPosition: "center",
            height: "300px",
          }}
        ></div>
        <h2 style={{ color: "#FF6B35", marginBottom: "15px" }}>Blog Post</h2>
        {contentParagraphs}
      </main>
      <footer
        style={{
          textAlign: "center",
          padding: "20px",
          backgroundColor: "#333",
          color: "white",
        }}
      >
        <a href="/" style={{ color: "#FF6B35", textDecoration: "none" }}>
          Back to Home
        </a>
      </footer>
    </div>
  );
};

export default BlogDetails;
