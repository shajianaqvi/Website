import React, { useState, useEffect, useCallback } from "react";
import { carouselItems } from "../util/carouselItems";

const Carousel = () => {
  const slides = carouselItems;

  const [currentIndex, setCurrentIndex] = useState(0);

  const goToNextSlide = useCallback(() => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length);
  }, [slides.length]);

  const goToPrevSlide = useCallback(() => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? slides.length - 1 : prevIndex - 1
    );
  }, [slides.length]);

  useEffect(() => {
    const interval = setInterval(goToNextSlide, 5000);
    return () => clearInterval(interval);
  }, [goToNextSlide]);

  return (
    <section id="carousel" className="section">
      <div className="container">
        <h2 className="section-title">Featured Campaigns</h2>
        <div className="carousel-container">
          <button
            className="carousel-button prev"
            onClick={goToPrevSlide}
            aria-label="Previous Slide"
          >
            &#8249;
          </button>
          <div className="carousel-track">
            {slides.map((slide, index) => (
              <div
                className={`carousel-slide ${
                  index === currentIndex ? "active" : ""
                }`}
                key={index}
                style={{
                  display: index === currentIndex ? "block" : "none",
                }}
              >
                <img src={slide.img} alt={slide.title} />
                <div className="carousel-caption">
                  <h3>{slide.title}</h3>
                  <p>{slide.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <button
            className="carousel-button next"
            onClick={goToNextSlide}
            aria-label="Next Slide"
          >
            &#8250;
          </button>
        </div>
      </div>
    </section>
  );
};

export default Carousel;
